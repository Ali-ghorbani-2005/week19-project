import React from 'react';

const InformationWeather = () => {
    return (
        <div>
            <div className='border-l mt-7' > 
                <div className='-mt-11'>
                <h1 className=' text-2xl text-white '>New York , USA </h1> 
                </div>
                <p className='text-white mt-20 ml-9'>Monday</p> 
                

                <div>
                    <h1 className='text-3xl text-white ml-9'>22</h1>  

                    <p className='text-white text-2xl ml-9'>71.62</p>
                </div>
            </div>
        </div>
    );
}

export default InformationWeather;
