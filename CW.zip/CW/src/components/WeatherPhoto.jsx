
const WeatherPhoto = () => {
    return (
        <div>  
            <p className="text-white -ml-6">parity Cloudy</p>

             <img src="imgs/Oxygen-Icons.org-Oxygen-Status-weather-clouds.256.png" alt="" className="w-36 h-36 " />
        </div>
    );
}

export default WeatherPhoto;
